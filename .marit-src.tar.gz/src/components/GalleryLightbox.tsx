"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { trackGalleryOpen } from "@/lib/analytics";

export function GalleryLightbox({
  images,
  title,
}: {
  images: string[];
  title: string;
}) {
  const [index, setIndex] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const prevRef = useRef<HTMLButtonElement>(null);
  const nextRef = useRef<HTMLButtonElement>(null);
  const lastFocus = useRef<HTMLElement | null>(null);
  const touchX = useRef<number | null>(null);
  const opened = useRef(false);
  const reduceMotion = useReducedMotion();
  const fade = reduceMotion ? 0 : 0.25;
  const scaleIn = reduceMotion ? 0 : 0.35;
  const multi = images.length > 1;

  useEffect(() => {
    if (index === null) {
      opened.current = false;
      return;
    }
    lastFocus.current = document.activeElement as HTMLElement;
    closeRef.current?.focus();
    if (!opened.current) {
      trackGalleryOpen({ title });
      opened.current = true;
    }

    const focusables = () =>
      [closeRef.current, prevRef.current, nextRef.current].filter(
        Boolean
      ) as HTMLElement[];

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setIndex(null);
      if (!multi) return;
      if (e.key === "ArrowRight")
        setIndex((i) => (i === null ? 0 : (i + 1) % images.length));
      if (e.key === "ArrowLeft")
        setIndex((i) =>
          i === null ? 0 : (i - 1 + images.length) % images.length
        );
      if (e.key === "Tab") {
        const nodes = focusables();
        if (!nodes.length) return;
        e.preventDefault();
        const current = document.activeElement as HTMLElement;
        const idx = nodes.indexOf(current);
        const next = e.shiftKey
          ? nodes[(idx - 1 + nodes.length) % nodes.length]
          : nodes[(idx + 1) % nodes.length];
        next.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      lastFocus.current?.focus();
    };
  }, [index, images.length, title, multi]);

  function onTouchStart(e: React.TouchEvent) {
    if (!multi) return;
    touchX.current = e.touches[0]?.clientX ?? null;
  }

  function onTouchEnd(e: React.TouchEvent) {
    if (!multi || touchX.current == null) return;
    const end = e.changedTouches[0]?.clientX ?? touchX.current;
    const delta = end - touchX.current;
    touchX.current = null;
    if (Math.abs(delta) < 48) return;
    if (delta < 0) {
      setIndex((i) => (i === null ? 0 : (i + 1) % images.length));
    } else {
      setIndex((i) =>
        i === null ? 0 : (i - 1 + images.length) % images.length
      );
    }
  }

  return (
    <>
      <div className="mx-auto grid max-w-7xl gap-4 px-5 pb-24 md:grid-cols-2 lg:grid-cols-3 md:px-8">
        {images.map((src, i) => (
          <button
            key={`${src}-${i}`}
            type="button"
            onClick={() => setIndex(i)}
            aria-label={`View ${title} image ${i + 1}`}
            className={`group relative overflow-hidden text-left ${
              i === 0 ? "md:col-span-2 md:aspect-[16/10]" : "aspect-[3/4]"
            }`}
          >
            <Image
              src={src}
              alt={`${title} detail ${i + 1}`}
              fill
              priority={i === 0}
              className="object-cover transition duration-700 group-hover:scale-[1.03]"
              sizes={
                i === 0
                  ? "(max-width: 768px) 100vw, (max-width: 1024px) 100vw, 66vw"
                  : "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw"
              }
            />
            <span className="absolute inset-0 bg-obsidian/0 transition group-hover:bg-obsidian/15" />
            <span className="absolute bottom-4 right-4 text-[10px] uppercase tracking-[0.2em] text-ivory/70 md:text-ivory/0 md:transition md:group-hover:text-ivory/80">
              View
            </span>
          </button>
        ))}
      </div>

      <AnimatePresence>
        {index !== null ? (
          <motion.div
            className="fixed inset-0 z-[120] flex items-center justify-center bg-obsidian/95 p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: fade }}
            onClick={() => setIndex(null)}
            onTouchStart={onTouchStart}
            onTouchEnd={onTouchEnd}
            role="dialog"
            aria-modal="true"
            aria-label={`${title} gallery`}
          >
            <button
              ref={closeRef}
              type="button"
              className="absolute right-5 top-5 text-[11px] uppercase tracking-[0.2em] text-taupe hover:text-ivory"
              onClick={() => setIndex(null)}
            >
              Close
            </button>
            {multi ? (
              <button
                ref={prevRef}
                type="button"
                className="absolute left-4 top-1/2 -translate-y-1/2 text-champagne md:left-8"
                onClick={(e) => {
                  e.stopPropagation();
                  setIndex((i) =>
                    i === null ? 0 : (i - 1 + images.length) % images.length
                  );
                }}
                aria-label="Previous image"
              >
                ←
              </button>
            ) : null}
            <motion.div
              key={index}
              className="relative h-[70vh] w-full max-w-5xl"
              initial={reduceMotion ? false : { opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={reduceMotion ? undefined : { opacity: 0 }}
              transition={{ duration: scaleIn }}
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={images[index]}
                alt={`${title} ${index + 1}`}
                fill
                className="object-contain"
                sizes="90vw"
                priority
              />
            </motion.div>
            {multi ? (
              <button
                ref={nextRef}
                type="button"
                className="absolute right-4 top-1/2 -translate-y-1/2 text-champagne md:right-8"
                onClick={(e) => {
                  e.stopPropagation();
                  setIndex((i) => (i === null ? 0 : (i + 1) % images.length));
                }}
                aria-label="Next image"
              >
                →
              </button>
            ) : null}
            <p className="absolute bottom-6 text-[11px] tracking-[0.18em] text-taupe">
              {index + 1} / {images.length}
              {multi ? (
                <span className="ml-3 text-taupe/60 md:hidden">Swipe</span>
              ) : null}
            </p>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  );
}
