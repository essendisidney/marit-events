import { Footer } from "@/components/Footer";
import { Navbar } from "@/components/Navbar";
import { MobileStickyBar, WhatsAppFloat } from "@/components/ConversionChrome";
import { Preloader } from "@/components/Preloader";
import { RouteTransition } from "@/components/RouteTransition";
import { RouteScrollReset } from "@/components/RouteScrollReset";
import { ScrollProgress } from "@/components/ScrollProgress";
import { BackToTop } from "@/components/BackToTop";

export function SiteChrome({ children }: { children: React.ReactNode }) {
  return (
    <>
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:bg-champagne focus:px-4 focus:py-2 focus:text-obsidian"
      >
        Skip to content
      </a>
      <Preloader />
      <RouteTransition />
      <RouteScrollReset />
      <ScrollProgress />
      <Navbar />
      <main id="main-content" tabIndex={-1} className="outline-none md:pb-0">
        {children}
      </main>
      <Footer />
      <WhatsAppFloat />
      <MobileStickyBar />
      <BackToTop />
    </>
  );
}
